<?php

namespace App\Http\Livewire\Admin\Components;

use Livewire\Component;

class Header extends Component
{
    public function render()
    {
        return view('livewire.admin.components.header');
    }
}
